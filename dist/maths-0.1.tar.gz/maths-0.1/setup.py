from setuptools import setup

setup(
	name='maths',
	version='0.1',
	description='add two values and return their sum',
	packages=['maths'],
	zip_safe=False)
